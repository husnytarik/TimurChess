import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import {
  getDatabase,
  ref,
  set,
  onValue,
  update,
  get,
  remove,
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  signOut,
  GoogleAuthProvider,
  signInWithPopup,
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";

// --- SENİN PROJE BİLGİLERİN ---
const firebaseConfig = {
  apiKey: "AIzaSyC7-WBfBIN5YwL-c3dua6jCsqpVJxIRfrI",
  authDomain: "timurchess-c2b78.firebaseapp.com",
  projectId: "timurchess-c2b78",
  storageBucket: "timurchess-c2b78.firebasestorage.app",
  messagingSenderId: "756724628338",
  appId: "1:756724628338:web:016b8f717728dc6d4ebbeb",
  databaseURL:
    "https://timurchess-c2b78-default-rtdb.europe-west1.firebasedatabase.app",
};
// ------------------------------

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

let currentUser = null; // Giriş yapmış kullanıcıyı burada tutacağız

window.Network = {
  // --- KİMLİK (AUTH) YÖNETİMİ ---

  // Uygulama başladığında kimin girdiğini takip et
  initAuth: (onLogin, onLogout) => {
    onAuthStateChanged(auth, (user) => {
      if (user) {
        console.log("Logged in:", user.email);
        currentUser = user;
        onLogin(user);
      } else {
        console.log("Logged out.");
        currentUser = null;
        onLogout();
      }
    });
  },

  // Email/Şifre ile Giriş
  login: async (email, pass) => {
    try {
      await signInWithEmailAndPassword(auth, email, pass);
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  },

  // Kayıt Ol
  register: async (email, pass) => {
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, pass);
      await initUserData(cred.user); // Veritabanında kullanıcı oluştur
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  },

  // GOOGLE İLE GİRİŞ (YENİ)
  loginGoogle: async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      await initUserData(result.user); // Kullanıcı ilk kez giriyorsa puan tablosunu oluştur
      return { success: true };
    } catch (e) {
      return { success: false, error: e.message };
    }
  },

  logout: () => signOut(auth),

  // --- OYUN YÖNETİMİ ---

  createGame: async (roomId) => {
    if (!currentUser) return null;

    const gameRef = ref(db, "games/" + roomId);
    await set(gameRef, {
      created: Date.now(),
      status: "waiting_ready",
      turn: "white",
      lastMove: null,
      playerWhite: currentUser.uid, // Artık SessionID değil, Gerçek UID
      playerBlack: null,
      readyWhite: false,
      readyBlack: false,
    });
    return "white";
  },

  joinGame: async (roomId) => {
    if (!currentUser) return { success: false, reason: "auth_error" };

    const gameRef = ref(db, "games/" + roomId);
    const snapshot = await get(gameRef);
    if (!snapshot.exists()) return { success: false, reason: "not_found" };

    const data = snapshot.val();

    // TEKRAR BAĞLANMA (REJOIN): Eğer zaten masadaysan rengini geri ver
    if (data.playerWhite === currentUser.uid) {
      return { success: true, color: "white", isRejoin: true };
    }
    if (data.playerBlack === currentUser.uid) {
      return { success: true, color: "black", isRejoin: true };
    }

    // Boş yer varsa otur
    if (!data.playerWhite) {
      await update(gameRef, { playerWhite: currentUser.uid });
      return { success: true, color: "white" };
    } else if (!data.playerBlack) {
      await update(gameRef, { playerBlack: currentUser.uid });
      return { success: true, color: "black" };
    } else {
      return { success: false, reason: "full" };
    }
  },

  // Masadan tamamen kalkmak için
  leaveGame: async (roomId, color) => {
    if (!currentUser) return;

    const updates = {};
    if (color === "white") updates.playerWhite = null;
    if (color === "black") updates.playerBlack = null;

    // Oyunu bekleme moduna al
    updates.status = "waiting_ready";
    updates.readyWhite = false;
    updates.readyBlack = false;

    await update(ref(db, "games/" + roomId), updates);
  },

  setReady: (roomId, color) => {
    const updates = {};
    if (color === "white") updates.readyWhite = true;
    if (color === "black") updates.readyBlack = true;
    update(ref(db, "games/" + roomId), updates);
  },

  startGame: (roomId) => {
    update(ref(db, "games/" + roomId), { status: "playing" });
  },

  sendMove: (roomId, moveData, nextTurn) => {
    update(ref(db, "games/" + roomId), { lastMove: moveData, turn: nextTurn });
  },

  listenGame: (roomId, callback) => {
    onValue(ref(db, "games/" + roomId), (snapshot) => {
      const data = snapshot.val();
      if (data) callback(data);
    });
  },

  savePeerId: (roomId, color, peerId) => {
    const updates = {};
    const field = color === "white" ? "peerWhite" : "peerBlack";
    updates[field] = peerId;
    update(ref(db, "games/" + roomId), updates);
  },

  // PUAN SİSTEMİ
  getMyScore: async () => {
    if (!currentUser) return 0;
    const snap = await get(ref(db, "users/" + currentUser.uid + "/score"));
    return snap.val() || 1000;
  },
};

// Yardımcı: Kullanıcı veritabanında yoksa oluştur (Başlangıç Puanı: 1000)
async function initUserData(user) {
  const userRef = ref(db, "users/" + user.uid);
  const snapshot = await get(userRef);
  if (!snapshot.exists()) {
    await set(userRef, {
      email: user.email,
      score: 1000,
      wins: 0,
      losses: 0,
    });
  }
}
