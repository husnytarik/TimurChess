// --- 1. KİMLİK DOĞRULAMA (AUTH) VE ARAYÜZ YÖNETİMİ ---

window.addEventListener("load", () => {
  // Sayfa açıldığında giriş yapılmış mı kontrol et
  window.Network.initAuth(
    (user) => {
      // GİRİŞ YAPILMIŞ:
      // 1. Auth ekranını gizle
      document.getElementById("auth-screen").classList.add("hidden");
      // 2. Lobiyi göster
      document.getElementById("lobby-screen").classList.remove("hidden");

      // 3. Kullanıcının puanını çekip konsola yaz (İstersen ekrana da yazdırabiliriz)
      window.Network.getMyScore().then((score) => {
        console.log(`Hoşgeldin ${user.email}. Puan: ${score}`);
      });
    },
    () => {
      // ÇIKIŞ YAPILMIŞ veya HİÇ GİRİLMEMİŞ:
      // 1. Auth ekranını göster
      document.getElementById("auth-screen").classList.remove("hidden");
      // 2. Diğer her şeyi gizle
      document.getElementById("lobby-screen").classList.add("hidden");
      document.getElementById("game-container").classList.add("hidden");
      document.getElementById("ui-panel").classList.add("hidden");
      document.getElementById("room-info").classList.add("hidden");
    },
  );
});

// GOOGLE İLE GİRİŞ
window.doGoogleLogin = async () => {
  const msg = document.getElementById("auth-msg");
  msg.textContent = "Google'a bağlanılıyor...";
  msg.className = "";

  const result = await window.Network.loginGoogle();

  if (!result.success) {
    msg.textContent = "Hata: " + result.error;
    msg.className = "msg-error";
  }
  // Başarılı olursa initAuth otomatik tetiklenip ekranı değiştirecek
};

// Form Değiştirme (Giriş <-> Kayıt)
window.toggleAuth = (mode) => {
  const msg = document.getElementById("auth-msg");
  msg.textContent = ""; // Hata mesajlarını temizle

  if (mode === "register") {
    document.getElementById("login-form").classList.add("hidden");
    document.getElementById("register-form").classList.remove("hidden");
  } else {
    document.getElementById("register-form").classList.add("hidden");
    document.getElementById("login-form").classList.remove("hidden");
  }
};

// Email ile Giriş Yap
window.doLogin = async () => {
  const email = document.getElementById("login-email").value;
  const pass = document.getElementById("login-pass").value;
  const msg = document.getElementById("auth-msg");

  if (!email || !pass) return; // Boşsa işlem yapma

  msg.textContent = "Giriş yapılıyor...";
  msg.className = "";

  const result = await window.Network.login(email, pass);
  if (!result.success) {
    msg.textContent = "Hata: " + result.error;
    msg.className = "msg-error";
  }
};

// Email ile Kayıt Ol
window.doRegister = async () => {
  const email = document.getElementById("reg-email").value;
  const pass = document.getElementById("reg-pass").value;
  const msg = document.getElementById("auth-msg");

  if (!email || !pass) return;

  msg.textContent = "Hesap oluşturuluyor...";
  msg.className = "";

  const result = await window.Network.register(email, pass);
  if (!result.success) {
    msg.textContent = "Hata: " + result.error;
    msg.className = "msg-error";
  } else {
    msg.textContent = "Başarılı! Giriş yapılıyor...";
    msg.className = "msg-success";
    // Kayıttan sonra otomatik giriş yapılır, initAuth devreye girer
  }
};

// Çıkış Yap
window.doLogout = () => {
  window.Network.logout();
  location.reload(); // Temiz bir başlangıç için sayfayı yenile
};

// --- 2. OYUN KURULUMU VE MANTIĞI ---

const canvas = document.getElementById("gameCanvas");
// Canvas boyutunu ayarla
canvas.width =
  CONFIG.BOARD.COLS * CONFIG.BOARD.TILE_SIZE + CONFIG.BOARD.OFFSET_X * 2;
canvas.height =
  CONFIG.BOARD.ROWS * CONFIG.BOARD.TILE_SIZE + CONFIG.BOARD.OFFSET_Y * 2;

const renderer = new Renderer(canvas);
const statusDiv = document.getElementById("status");

let state = {
  pieces: [],
  turn: "white",
  myColor: null,
  roomId: null,
  selectedPiece: null,
  legalMoves: [],
  gameOver: false,
  gameStarted: false,
  hoverSquare: null,
  errorSquare: null,
  timers: {
    white: CONFIG.GAME.TIME_LIMIT_SECONDS,
    black: CONFIG.GAME.TIME_LIMIT_SECONDS,
  },
  interval: null,
};

// ODA OLUŞTURMA
window.createRoom = async () => {
  const roomId = Math.random().toString(36).substring(2, 7).toUpperCase();
  document.getElementById("lobby-status").textContent = "Oda oluşturuluyor...";

  const assignedColor = await window.Network.createGame(roomId);

  if (assignedColor) {
    state.myColor = assignedColor;
    state.roomId = roomId;
    startGameUI(roomId);
  } else {
    alert("Hata: Giriş yapmamış olabilirsiniz.");
  }
};

// ODAYA KATILMA
window.joinRoom = async () => {
  const roomId = document
    .getElementById("room-code-input")
    .value.toUpperCase()
    .trim();
  if (!roomId) return alert("Lütfen oda kodu girin!");

  document.getElementById("lobby-status").textContent = "Bağlanılıyor...";

  const result = await window.Network.joinGame(roomId);

  if (result.success) {
    state.myColor = result.color;
    state.roomId = roomId;

    // Eğer tekrar bağlandıysa (Rejoin) kullanıcıyı bilgilendir
    if (result.isRejoin) {
      console.log("Oyuna tekrar bağlandınız.");
    }

    startGameUI(roomId);
  } else {
    if (result.reason === "full") alert("Oda dolu!");
    else if (result.reason === "not_found") alert("Oda bulunamadı!");
    else alert("Giriş hatası!");

    document.getElementById("lobby-status").textContent = "";
  }
};

// OYUN ARAYÜZÜNÜ BAŞLAT
function startGameUI(roomId) {
  // Ekranları değiştir
  document.getElementById("lobby-screen").classList.add("hidden");
  document.getElementById("room-info").classList.remove("hidden");
  document.getElementById("ui-panel").classList.remove("hidden");
  document.getElementById("game-container").classList.remove("hidden");

  // Bilgileri yaz
  document.getElementById("display-room-id").textContent = roomId;
  document.getElementById("my-role").textContent =
    state.myColor === "white" ? "BEYAZ (Ev Sahibi)" : "SİYAH (Misafir)";

  // Sesli Sohbeti Başlat
  const myVoiceId = `${roomId}_${state.myColor}`;
  window.Voice.init(myVoiceId).then(() => {
    window.Network.savePeerId(roomId, state.myColor, myVoiceId);
  });

  initGame();
}

// HAZIR OL BUTONU
window.setMyReady = () => {
  const btn = document.getElementById("btn-set-ready");
  btn.textContent = "Hazır, Bekleniyor...";
  btn.disabled = true;
  btn.style.background = "#95a5a6";
  window.Network.setReady(state.roomId, state.myColor);
};

// OYUNU BAŞLAT (Verileri ve Loop'u hazırla)
function initGame() {
  state.pieces = CONFIG.INITIAL_SETUP.map((d) => new Piece(d.t, d.c, d.x, d.y));
  state.gameOver = false;
  state.gameStarted = false;

  // Firebase'den gelen güncellemeleri dinle
  window.Network.listenGame(state.roomId, (serverData) => {
    handleServerUpdate(serverData);
  });

  gameLoop();
}

let lastProcessedMove = null;

// SUNUCUDAN GELEN VERİYİ İŞLE
function handleServerUpdate(data) {
  if (!data) return;

  updateReadyStatusUI(data);

  // Sesli Sohbet Bağlantısı (Sadece Beyaz arama yapar)
  if (state.myColor === "white" && data.peerBlack && !window.Voice.call) {
    window.Voice.connectToPeer(data.peerBlack);
  }

  // Oyun Durumu Kontrolü
  if (data.status === "playing" && !state.gameStarted) {
    state.gameStarted = true;
    document.getElementById("ready-overlay").classList.add("hidden");
    startTimer();
  } else if (
    data.status !== "playing" &&
    data.readyWhite &&
    data.readyBlack &&
    state.myColor === "white"
  ) {
    // İki taraf da hazırsa Beyaz oyunu başlatır
    window.Network.startGame(state.roomId);
  }

  state.turn = data.turn;
  updateStatusText();

  // Hamle Geldi mi?
  if (
    data.lastMove &&
    JSON.stringify(data.lastMove) !== JSON.stringify(lastProcessedMove)
  ) {
    const move = data.lastMove;
    const piece = state.pieces.find(
      (p) => p.x === move.from.x && p.y === move.from.y,
    );

    if (piece) {
      // Hedefte taş varsa ye
      const targetIndex = state.pieces.findIndex(
        (p) => p.x === move.to.x && p.y === move.to.y,
      );
      if (targetIndex !== -1) state.pieces.splice(targetIndex, 1);

      // Taşı oynat
      piece.x = move.to.x;
      piece.y = move.to.y;

      // Terfi Kontrolü
      const newType = GameLogic.checkPromotion(piece);
      if (newType) piece.type = newType;
    }
    lastProcessedMove = data.lastMove;
    checkGameState();
  }
}

// HAZIRLIK DURUMUNU GÜNCELLE
function updateReadyStatusUI(data) {
  const wSpan = document.getElementById("status-white");
  const bSpan = document.getElementById("status-black");
  const msg = document.getElementById("waiting-msg");

  if (data.playerWhite) {
    wSpan.textContent = data.readyWhite ? "HAZIR" : "Bekliyor...";
    wSpan.className = data.readyWhite
      ? "player-tag tag-ready"
      : "player-tag tag-waiting";
  } else {
    wSpan.textContent = "Bağlı Değil";
  }

  if (data.playerBlack) {
    bSpan.textContent = data.readyBlack ? "HAZIR" : "Bekliyor...";
    bSpan.className = data.readyBlack
      ? "player-tag tag-ready"
      : "player-tag tag-waiting";
    msg.textContent = "Her iki oyuncu da hazır olduğunda oyun başlar...";
  } else {
    bSpan.textContent = "Bağlı Değil";
    msg.textContent = "Rakip bekleniyor...";
  }
}

// SIRA KİMDE YAZISINI GÜNCELLE
function updateStatusText() {
  if (state.turn === state.myColor) {
    statusDiv.textContent = "SIRA SENDE!";
    statusDiv.style.backgroundColor = "#27ae60";
  } else {
    statusDiv.textContent = "Rakip düşünüyor...";
    statusDiv.style.backgroundColor = "#c0392b";
  }
}

// ZAMANLAYICI
function startTimer() {
  if (state.interval) clearInterval(state.interval);

  state.interval = setInterval(() => {
    if (!state.gameStarted || state.gameOver) return;

    state.timers[state.turn]--;

    formatTime("timer-white", state.timers.white);
    formatTime("timer-black", state.timers.black);

    if (state.timers[state.turn] <= 0) {
      endGame(state.turn === "white" ? "black" : "white", "Süre Bitti!");
    }
  }, 1000);
}

function formatTime(elementId, seconds) {
  const m = Math.floor(seconds / 60)
    .toString()
    .padStart(2, "0");
  const s = (seconds % 60).toString().padStart(2, "0");
  document.getElementById(elementId).textContent = `${m}:${s}`;
}

// --- 3. OYUN DÖNGÜSÜ (RENDER LOOP) ---

function gameLoop() {
  const now = Date.now();
  renderer.setPerspective(state.myColor || "white");
  renderer.clear();
  renderer.drawBoard();

  // Hover Efekti
  if (state.hoverSquare) {
    renderer.drawPulseSquare(
      state.hoverSquare,
      CONFIG.THEME.COLOR_HOVER,
      now,
      "hover",
    );
  }

  // Geçerli Hamleleri Göster
  state.legalMoves.forEach((move) => {
    const color = move.isCapture
      ? CONFIG.THEME.COLOR_CAPTURE
      : CONFIG.THEME.COLOR_VALID;
    renderer.drawPulseSquare(move, color, now, "move");
  });

  // Hatalı Tıklama Efekti
  if (state.errorSquare) {
    if (now - state.errorSquare.time < 500) {
      renderer.drawSolidSquare(
        state.errorSquare,
        CONFIG.THEME.COLOR_INVALID,
        0.6,
      );
    } else {
      state.errorSquare = null;
    }
  }

  // Şah Çekildi mi?
  let kingCheckPos = null;
  if (GameLogic.isKingInCheck(state.turn, state.pieces)) {
    const k = state.pieces.find(
      (p) =>
        (p.type === "king" || p.type === "prince") && p.color === state.turn,
    );
    if (k) kingCheckPos = { x: k.x, y: k.y };
  }

  renderer.drawHighlights(state.selectedPiece, kingCheckPos);
  state.pieces.forEach((p) => renderer.drawPiece(p));

  requestAnimationFrame(gameLoop);
}

// --- 4. ETKİLEŞİM VE KONTROLLER (MOUSE & TOUCH) ---

// Responsive Koordinat Hesabı (Telefonda ve PC'de düzgün çalışması için)
function getLogicalPos(evt) {
  const rect = canvas.getBoundingClientRect();

  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;

  const clientX = evt.clientX || (evt.touches && evt.touches[0].clientX);
  const clientY = evt.clientY || (evt.touches && evt.touches[0].clientY);

  const realX = (clientX - rect.left) * scaleX;
  const realY = (clientY - rect.top) * scaleY;

  let col = Math.floor(
    (realX - CONFIG.BOARD.OFFSET_X) / CONFIG.BOARD.TILE_SIZE,
  );
  let row = Math.floor(
    (realY - CONFIG.BOARD.OFFSET_Y) / CONFIG.BOARD.TILE_SIZE,
  );

  if (state.myColor === "black") {
    col = CONFIG.BOARD.COLS - 1 - col;
    row = CONFIG.BOARD.ROWS - 1 - row;
  }

  return { col, row };
}

// Mouse Hareketi (Hover)
canvas.addEventListener("mousemove", (e) => {
  const pos = getLogicalPos(e);
  const col = pos.col;
  const row = pos.row;

  const isValidMain =
    col >= 0 && col < CONFIG.BOARD.COLS && row >= 0 && row < CONFIG.BOARD.ROWS;
  const isLeftCitadel = col === -1 && row === 2;
  const isRightCitadel = col === 11 && row === 7;

  if (isValidMain || isLeftCitadel || isRightCitadel) {
    state.hoverSquare = { x: col, y: row };
  } else {
    state.hoverSquare = null;
  }
});

// Tıklama (Hamle Yapma)
canvas.addEventListener("click", (e) => {
  if (state.gameOver || !state.gameStarted) return;
  if (state.turn !== state.myColor) return;

  // Mobilde hover olmadığı için tıklama anında pozisyonu al
  const pos = getLogicalPos(e);
  const col = pos.col;
  const row = pos.row;

  // Tıklanan yer geçerli mi?
  const isValidMain =
    col >= 0 && col < CONFIG.BOARD.COLS && row >= 0 && row < CONFIG.BOARD.ROWS;
  const isLeftCitadel = col === -1 && row === 2;
  const isRightCitadel = col === 11 && row === 7;

  if (!isValidMain && !isLeftCitadel && !isRightCitadel) return;

  const move = state.legalMoves.find((m) => m.x === col && m.y === row);

  // Eğer seçili taş varsa ve tıklanan yer geçerli bir hamleyse -> OYNA
  if (state.selectedPiece && move) {
    executeMove(move);
    return;
  }

  const clickedPiece = state.pieces.find((p) => p.x === col && p.y === row);

  // Kendi taşına tekrar tıklarsan seçimi kaldır
  if (
    state.selectedPiece &&
    clickedPiece &&
    state.selectedPiece === clickedPiece
  ) {
    state.selectedPiece = null;
    state.legalMoves = [];
    state.errorSquare = null;
    return;
  }

  // Yeni bir taş seç
  if (clickedPiece && clickedPiece.color === state.myColor) {
    state.selectedPiece = clickedPiece;
    const moves = GameLogic.getLegalMoves(clickedPiece, state.pieces);
    state.legalMoves = moves.map((m) => {
      const target = state.pieces.find((p) => p.x === m.x && p.y === m.y);
      return { ...m, isCapture: !!target };
    });
    state.errorSquare = null;
  } else if (state.selectedPiece) {
    // Boş yere veya rakibe tıkladı ama hamle değil -> Hata göster
    state.errorSquare = { x: col, y: row, time: Date.now() };
  } else {
    state.selectedPiece = null;
    state.legalMoves = [];
  }
});

// Hamleyi Uygula ve Sunucuya Gönder
function executeMove(move) {
  const fromPos = { x: state.selectedPiece.x, y: state.selectedPiece.y };
  const toPos = { x: move.x, y: move.y };

  // Eğer hedefte taş varsa sil (Client tarafında anlık görüntü için)
  const targetIndex = state.pieces.findIndex(
    (p) => p.x === move.x && p.y === move.y,
  );
  if (targetIndex !== -1) state.pieces.splice(targetIndex, 1);

  // Taşı taşı
  state.selectedPiece.x = move.x;
  state.selectedPiece.y = move.y;

  // Terfi
  const newType = GameLogic.checkPromotion(state.selectedPiece);
  if (newType) state.selectedPiece.type = newType;

  // Seçimi temizle
  state.selectedPiece = null;
  state.legalMoves = [];

  // Sırayı değiştir ve gönder
  const nextTurn = state.turn === "white" ? "black" : "white";
  lastProcessedMove = { from: fromPos, to: toPos };

  window.Network.sendMove(state.roomId, { from: fromPos, to: toPos }, nextTurn);
  checkGameState();
}

// Oyun Bitti mi Kontrolü
function checkGameState() {
  const myPieces = state.pieces.filter((p) => p.color === state.turn);
  const hasMove = myPieces.some(
    (p) => GameLogic.getLegalMoves(p, state.pieces).length > 0,
  );

  if (!hasMove) {
    if (GameLogic.isKingInCheck(state.turn, state.pieces)) {
      endGame(state.turn === "white" ? "black" : "white", "ŞAH MAT");
    } else {
      endGame("draw", "PAT (Berabere)");
    }
  }
}

// Oyunu Bitir
function endGame(winner, reason) {
  state.gameOver = true;
  clearInterval(state.interval);

  if (winner === "draw") {
    statusDiv.textContent = `OYUN BİTTİ - BERABERE (${reason})`;
    statusDiv.style.backgroundColor = "#7f8c8d";
  } else {
    const winnerText = winner === "white" ? "BEYAZ" : "SİYAH";
    statusDiv.textContent = `OYUN BİTTİ - ${winnerText} KAZANDI (${reason})`;
    statusDiv.style.backgroundColor = "#f39c12";

    // Kazananın puanını artır (Opsiyonel - Firebase tarafında yapmak daha güvenli ama şimdilik burada)
    if (winner === state.myColor) {
      // window.Network.updateScore(auth.currentUser.uid, 10);
    }
  }
}

// Mobil Dokunmatik Desteği (Touch -> Click çevirici)
canvas.addEventListener(
  "touchstart",
  (e) => {
    e.preventDefault();
    const touch = e.touches[0];
    const mouseEvent = new MouseEvent("click", {
      clientX: touch.clientX,
      clientY: touch.clientY,
    });
    canvas.dispatchEvent(mouseEvent);
  },
  { passive: false },
);
